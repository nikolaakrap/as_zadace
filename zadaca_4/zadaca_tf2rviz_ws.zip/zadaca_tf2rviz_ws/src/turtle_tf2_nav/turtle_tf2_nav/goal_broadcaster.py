import math
from geometry_msgs.msg import TransformStamped, PoseStamped
from turtlesim.msg import Pose
import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import Twist

class FramePublisher(Node):

    def __init__(self):
        super().__init__('goal_broadcaster')

        # Initialize the transform broadcaster
        self.tf_broadcaster = TransformBroadcaster(self)
       
        self.subscription = self.create_subscription(
            PoseStamped,
            '/goal_pose',
            self.handle_goal_2d,
            1)    
       
        self.pose_sub = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.update_current_pose,
        1)

        self.cmd_pub = self.create_publisher(Twist, 'turtle1/cmd_vel',1)

        self.subscription # prevent unused variable warning
        self.timer = self.create_timer(0.1, self.control_loop)
        self.pos_and_orient = [None, None, None, None, None, None, None]
        self.current_pose = None

    def broadcast_tf2(self):
        if(self.pos_and_orient[0] == None):
            pass
        else:
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = 'world'
            t.child_frame_id = '2d_goal_tf'
            t.transform.translation.x = self.pos_and_orient[0]
            t.transform.translation.y = self.pos_and_orient[1]
            t.transform.translation.z = self.pos_and_orient[2]
            t.transform.rotation.x = self.pos_and_orient[3]
            t.transform.rotation.y = self.pos_and_orient[4]
            t.transform.rotation.z = self.pos_and_orient[5]
            t.transform.rotation.w = self.pos_and_orient[6]
           
            self.tf_broadcaster.sendTransform(t)

    def handle_goal_2d(self, msg):
        self.pos_and_orient[0] = msg.pose.position.x
        self.pos_and_orient[1] = msg.pose.position.y
        self.pos_and_orient[2] = msg.pose.position.z
        self.pos_and_orient[3] = msg.pose.orientation.x
        self.pos_and_orient[4] = msg.pose.orientation.y
        self.pos_and_orient[5] = msg.pose.orientation.z
        self.pos_and_orient[6] = msg.pose.orientation.w
   
    def update_current_pose(self, msg):
        self.current_pose = msg
   
    def control_loop(self):
        self.broadcast_tf2()

        if self.current_pose is None or self.pos_and_orient[0] is None:
            return

        goal_x = self.pos_and_orient[0]
        goal_y = self.pos_and_orient[1]
        x = self.current_pose.x
        y = self.current_pose.y
        theta = self.current_pose.theta

        # Razlika i udaljenost
        dx = goal_x - x
        dy = goal_y - y
        distance = math.sqrt(dx**2 + dy**2)

        if distance < 0.1:
            # Stigli smo do cilja
            self.cmd_pub.publish(Twist())  # pošalji nule
            return

        # Kut prema cilju
        target_angle = math.atan2(dy, dx)
        angle_diff = self.normalize_angle(target_angle - theta)

        cmd = Twist()

        # Ako kut nije dobar, prvo rotiraj
        if abs(angle_diff) > 0.1:
            cmd.angular.z = 2.0 * angle_diff
        else:
            cmd.linear.x = 1.5 * distance

        self.cmd_pub.publish(cmd)

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle

def main():
    rclpy.init()
    node = FramePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()