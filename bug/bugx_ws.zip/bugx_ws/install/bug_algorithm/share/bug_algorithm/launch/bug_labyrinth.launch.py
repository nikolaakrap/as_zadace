import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():
    pkg_dir = get_package_share_directory('bug_algorithm')
    world_file = os.path.join(pkg_dir, 'worlds', 'labyrinth.sdf')
    
    # Create the RViz configuration directory and file
    os.makedirs(os.path.join(pkg_dir, 'rviz'), exist_ok=True)
    rviz_config = os.path.join(pkg_dir, 'rviz', 'bug_nav.rviz')
    
    # Start Ignition Gazebo
    gazebo = ExecuteProcess(
        cmd=['ign', 'gazebo', '-r', world_file],
        output='screen'
    )
    
    # Bridge for Ignition to ROS
    bridge = Node(
        package='ros_ign_bridge',
        executable='parameter_bridge',
        arguments=[
            '/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
            '/scan@sensor_msgs/msg/LaserScan@ignition.msgs.LaserScan',
        ],
        output='screen'
    )
    
    # Map to odom transform
    static_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom'],
        output='screen'
    )
    
    # Scan to range converter
    scan_to_range = Node(
        package='bug_algorithm',
        executable='scan_to_range',
        name='scan_to_range',
        output='screen'
    )
    
    # Bug algorithm
    bug = Node(
        package='bug_algorithm',
        executable='bugx',
        name='bugx',
        output='screen'
    )
    
    # RViz
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen'
    )
    
    return LaunchDescription([
        gazebo,
        bridge,
        static_tf,
        scan_to_range,
        bug,
        rviz
    ])