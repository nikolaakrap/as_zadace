from setuptools import setup
import os
from glob import glob

package_name = 'bug_algorithm'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.sdf')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your_email@example.com',
    description='Bug algorithm for maze navigation',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'scan_to_range = bug_algorithm.scan_to_range:main',
            'bugx = bug_algorithm.bugx:main',
            'goal_publisher = bug_algorithm.goal_publisher:main',
            'goal_converter = bug_algorithm.goal_converter:main',
            'tf_publisher = bug_algorithm.tf_publisher:main',
        ],
    },
)