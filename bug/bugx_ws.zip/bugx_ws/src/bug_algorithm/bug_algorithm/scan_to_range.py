import sys
import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, Range

class ConvertScanToRange(Node):

    def __init__(self):
        super().__init__('scan_to_range')
        self.lidar_subscriber = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10)
        self.fl_range_sensor = self.create_publisher(Range, '/fl_range_sensor', 10)
        self.fr_range_sensor = self.create_publisher(Range, '/fr_range_sensor', 10)
        self.l_range_sensor = self.create_publisher(Range, '/l_range_sensor', 10)
        self.r_range_sensor = self.create_publisher(Range, '/r_range_sensor', 10)
        self.f_range_sensor = self.create_publisher(Range, '/f_range_sensor', 10)
        
        # Debug counter
        self.counter = 0
        self.get_logger().info('Scan to Range converter initialized')

    def lidar_callback(self, msg):
        self.counter += 1
        
        # Helper function to get minimum valid reading from a section
        def getmin(start_index, end_index):
            # Handle wrap-around if needed
            if start_index > end_index:
                section = list(msg.ranges[start_index:]) + list(msg.ranges[:end_index])
            else:
                section = list(msg.ranges[start_index:end_index])
            
            # Filter valid ranges
            valid_ranges = []
            for r in section:
                if not math.isnan(r) and not math.isinf(r) and msg.range_min <= r <= msg.range_max:
                    valid_ranges.append(r)
            
            if valid_ranges:
                return min(valid_ranges)
            else:
                return float('inf')
                
        # Calculate indices based on angle increments
        angle_increment = msg.angle_increment
        total_angles = len(msg.ranges)
        
        # Front sector (centered at 0 degrees or in the middle of the array)
        front_center = 0  # Assuming 0 radians is front
        front_index = int((front_center - msg.angle_min) / angle_increment)
        front_range = getmin(
            (front_index - int(15 * math.pi / 180 / angle_increment)) % total_angles,  # -15 degrees
            (front_index + int(15 * math.pi / 180 / angle_increment)) % total_angles   # +15 degrees
        )
        
        # Front-left sector (around 30 degrees)
        fl_center = 30 * math.pi / 180  # 30 degrees in radians
        fl_index = int((fl_center - msg.angle_min) / angle_increment)
        fl_range = getmin(
            (fl_index - int(15 * math.pi / 180 / angle_increment)) % total_angles,  # 15 degrees
            (fl_index + int(15 * math.pi / 180 / angle_increment)) % total_angles   # 45 degrees
        )
        
        # Front-right sector (around -30 degrees or 330 degrees)
        fr_center = -30 * math.pi / 180  # -30 degrees in radians
        fr_index = int((fr_center - msg.angle_min) / angle_increment) % total_angles
        fr_range = getmin(
            (fr_index - int(15 * math.pi / 180 / angle_increment)) % total_angles,  # -45 degrees
            (fr_index + int(15 * math.pi / 180 / angle_increment)) % total_angles   # -15 degrees
        )
        
        # Left sector (around 90 degrees)
        left_center = 90 * math.pi / 180  # 90 degrees in radians
        left_index = int((left_center - msg.angle_min) / angle_increment)
        left_range = getmin(
            (left_index - int(15 * math.pi / 180 / angle_increment)) % total_angles,  # 75 degrees
            (left_index + int(15 * math.pi / 180 / angle_increment)) % total_angles   # 105 degrees
        )
        
        # Right sector (around -90 degrees or 270 degrees)
        right_center = -90 * math.pi / 180  # -90 degrees in radians
        right_index = int((right_center - msg.angle_min) / angle_increment) % total_angles
        right_range = getmin(
            (right_index - int(15 * math.pi / 180 / angle_increment)) % total_angles,  # -105 degrees
            (right_index + int(15 * math.pi / 180 / angle_increment)) % total_angles   # -75 degrees
        )
        
        # Log results occasionally
        if self.counter % 100 == 0:
            self.get_logger().info(f"F: {front_range:.2f}, FL: {fl_range:.2f}, FR: {fr_range:.2f}, L: {left_range:.2f}, R: {right_range:.2f}")
        
        # Create and publish Range messages
        self.publish_range(self.f_range_sensor, "f_sensor_link", front_range, msg)
        self.publish_range(self.fl_range_sensor, "fl_sensor_link", fl_range, msg)
        self.publish_range(self.fr_range_sensor, "fr_sensor_link", fr_range, msg)
        self.publish_range(self.l_range_sensor, "l_sensor_link", left_range, msg)
        self.publish_range(self.r_range_sensor, "r_sensor_link", right_range, msg)

    def publish_range(self, publisher, frame_id, range_value, original_msg):
        msg = Range()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = frame_id
        msg.radiation_type = Range.INFRARED
        msg.field_of_view = 0.17  # approximately 10 degrees
        msg.min_range = original_msg.range_min
        msg.max_range = original_msg.range_max
        msg.range = range_value
        publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    converter = ConvertScanToRange()
    rclpy.spin(converter)
    converter.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()