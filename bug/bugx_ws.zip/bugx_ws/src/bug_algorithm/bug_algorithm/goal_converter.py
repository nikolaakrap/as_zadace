import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped

class GoalConverter(Node):
    def __init__(self):
        super().__init__('goal_converter')
        
        # Subscribe to RViz "2D Pose Goal" topics
        self.subscription = self.create_subscription(
            PoseStamped,
            '/goal_pose',
            self.goal_callback,
            10)
        
        # Forward the goal to the bug algorithm
        self.goal_publisher = self.create_publisher(
            PoseStamped,
            '/goal_pose',  # Same topic as the one expected by the bug algorithm
            10)
        
        self.get_logger().info('Goal converter initialized - Ready to receive goals from RViz')

    def goal_callback(self, msg):
        # The message from RViz already has the format we need, so we just forward it
        # But we can log the received goal for monitoring
        self.get_logger().info(f'Received goal from RViz: x={msg.pose.position.x}, y={msg.pose.position.y}')
        self.goal_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    goal_converter = GoalConverter()
    rclpy.spin(goal_converter)
    goal_converter.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()