import math
import rclpy
from rclpy.node import Node
import tf_transformations as transform
from geometry_msgs.msg import Twist, PoseStamped
from sensor_msgs.msg import Range
from nav_msgs.msg import Odometry

class Bug0(Node):
    #Initialization
    def __init__(self):
        super().__init__('bugx')
        self.odom_subscriber = self.create_subscription(Odometry, '/odom', self.location_callback, 10)
        self.fl_sensor_sub = self.create_subscription(Range, '/fl_range_sensor', self.fl_sensor_callback, 10)
        self.fr_sensor_sub = self.create_subscription(Range, '/fr_range_sensor', self.fr_sensor_callback, 10)
        self.r_sensor_sub = self.create_subscription(Range, '/r_range_sensor', self.r_sensor_callback, 10)
        self.l_sensor_sub = self.create_subscription(Range, '/l_range_sensor', self.l_sensor_callback, 10)
        self.f_sensor_sub = self.create_subscription(Range, '/f_range_sensor', self.f_sensor_callback, 10)       
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.target_sub = self.create_subscription(PoseStamped, '/goal_pose', self.goal_callback, 10)
        self.bug_algorithm_timer = self.create_timer(0.1, self.bug_algorithm_callback)
        
        # Initialize parameters
        self.goal_x = None
        self.goal_y = None
        self._state = 0
        self.current_x = 0
        self.current_y = 0
        self.current_theta = 0
        self.fl_sensor_value = 2.0  # Safe initial value
        self.fr_sensor_value = 2.0
        self.l_sensor_value = 2.0
        self.r_sensor_value = 2.0
        self.f_sensor_value = 2.0
        self.cmd_vel_msg = Twist()
        self.state = "GO_TO_GOAL"
        
        # Add these variables to track wall following state
        self.wall_follow_direction = "LEFT"  # Default direction to turn when following wall
        self.follow_wall_counter = 0        # Counter to prevent getting stuck
        self.max_follow_wall_count = 50     # Maximum iterations to stay in FOLLOW_WALL before trying GO_TO_GOAL
        self.prev_distance_to_goal = float('inf')  # Track previous distance to goal
        
        self.get_logger().info('Bug algorithm initialized - waiting for goal')

    #Method for goal update
    def goal_callback(self, msg):
        self.goal_x = msg.pose.position.x
        self.goal_y = msg.pose.position.y
        self.prev_distance_to_goal = float('inf')  # Reset this when new goal received
        self.get_logger().info(f'New goal received: x={self.goal_x}, y={self.goal_y}')
        
        # Reset to GO_TO_GOAL state when a new goal is received
        self.state = "GO_TO_GOAL"
        self.follow_wall_counter = 0

    #Method for robot current position
    def location_callback(self, msg):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y
        q = (
                msg.pose.pose.orientation.x,
                msg.pose.pose.orientation.y,
                msg.pose.pose.orientation.z,
                msg.pose.pose.orientation.w)
        self.current_theta = transform.euler_from_quaternion(q)[2] #[-pi, pi]

    #Methods for updating sensor values with validation
    def fl_sensor_callback(self, msg):
        if not math.isnan(msg.range) and not math.isinf(msg.range):
            self.fl_sensor_value = msg.range  # front left

    def fr_sensor_callback(self, msg):
        if not math.isnan(msg.range) and not math.isinf(msg.range):
            self.fr_sensor_value = msg.range  # front right
    
    def r_sensor_callback(self, msg):
        if not math.isnan(msg.range) and not math.isinf(msg.range):
            self.r_sensor_value = msg.range
            
    def l_sensor_callback(self, msg):
        if not math.isnan(msg.range) and not math.isinf(msg.range):
            self.l_sensor_value = msg.range

    def f_sensor_callback(self, msg):
        if not math.isnan(msg.range) and not math.isinf(msg.range):
            self.f_sensor_value = msg.range  # front

    def bug_algorithm_callback(self):
        if self.goal_x is None or self.goal_y is None:
            # No goal set yet, stop the robot
            self.stop_robot()
            return
            
        # Log current position and sensor values periodically
        self.get_logger().debug(f"Position: ({self.current_x:.2f}, {self.current_y:.2f}), Heading: {self.current_theta:.2f}")
        self.get_logger().debug(f"Sensors: F={self.f_sensor_value:.2f}, FL={self.fl_sensor_value:.2f}, FR={self.fr_sensor_value:.2f}")
        
        # Current distance to goal
        current_distance = self.distance_to_goal()
        
        # Check if goal is reached
        if current_distance < 0.2:
            self.get_logger().info('Goal reached!')
            self.stop_robot()
            return
            
        # State machine
        if self.state == "GO_TO_GOAL":
            if self.f_sensor_value < 0.5:
                self.state = "FOLLOW_WALL"
                self.wall_follow_direction = "LEFT"  # Default direction
                self.follow_wall_counter = 0
                self.get_logger().info("Obstacle detected - switching to FOLLOW_WALL")
            else:
                self.go_to_goal()
                
        elif self.state == "FOLLOW_WALL":
            # Increment counter to prevent getting stuck
            self.follow_wall_counter += 1
            
            # Check if path to goal is clear and we're getting closer
            if (self.f_sensor_value > 0.7 and  # Front is clear
                current_distance < self.prev_distance_to_goal):  # Getting closer to goal
                self.state = "GO_TO_GOAL"
                self.get_logger().info("Path is clear - switching to GO_TO_GOAL")
                
            # Force switch to GO_TO_GOAL periodically to prevent getting stuck
            elif self.follow_wall_counter > self.max_follow_wall_count:
                self.state = "GO_TO_GOAL"
                self.get_logger().info("Forcing switch to GO_TO_GOAL to prevent getting stuck")
                self.follow_wall_counter = 0
            else:
                self.follow_wall()
                
        # Update previous distance to goal
        self.prev_distance_to_goal = current_distance

    def go_to_goal(self):
        # Calculate angle to goal
        angle_to_goal = math.atan2(self.goal_y - self.current_y, self.goal_x - self.current_x)
        angle_diff = self.normalize_angle(angle_to_goal - self.current_theta)
        
        # Log movement decisions
        self.get_logger().debug(f"GO_TO_GOAL: angle_diff = {angle_diff:.2f}")
        
        # First turn to face the goal
        if abs(angle_diff) > 0.2:  # If not facing goal, prioritize turning
            self.cmd_vel_msg.linear.x = 0.0  # Stop and turn in place
            self.cmd_vel_msg.angular.z = 0.5 * angle_diff  # Turn rate proportional to angle difference
            self.get_logger().debug("Turning to face goal")
        else:
            # Move forward toward the goal
            self.cmd_vel_msg.linear.x = 0.15  # Move forward
            self.cmd_vel_msg.angular.z = 0.3 * angle_diff  # Small correction to keep on track
            self.get_logger().debug("Moving toward goal")
        
        self.cmd_pub.publish(self.cmd_vel_msg)

    def follow_wall(self):
        # Log current wall-following state
        self.get_logger().debug(f"FOLLOW_WALL: direction={self.wall_follow_direction}, counter={self.follow_wall_counter}")
        
        # Improved wall-following logic
        if self.f_sensor_value < 0.4:  # Obstacle very close in front
            # Turn sharply to avoid collision
            self.cmd_vel_msg.linear.x = 0.0
            self.cmd_vel_msg.angular.z = 0.7 if self.wall_follow_direction == "LEFT" else -0.7
            self.get_logger().debug("Turning to avoid front obstacle")
            
        elif self.fl_sensor_value < 0.4:  # Obstacle on front-left
            # Adjust path to the right
            self.cmd_vel_msg.linear.x = 0.1
            self.cmd_vel_msg.angular.z = -0.5  # Turn right
            self.get_logger().debug("Adjusting to avoid front-left obstacle")
            
        elif self.fr_sensor_value < 0.4:  # Obstacle on front-right
            # Adjust path to the left
            self.cmd_vel_msg.linear.x = 0.1
            self.cmd_vel_msg.angular.z = 0.5  # Turn left
            self.get_logger().debug("Adjusting to avoid front-right obstacle")
            
        else:
            # Move forward with slight turn to follow wall contour
            self.cmd_vel_msg.linear.x = 0.15
            
            # Choose turn direction based on obstacles
            if self.l_sensor_value < self.r_sensor_value:
                # Wall on left, turn slightly right
                self.cmd_vel_msg.angular.z = -0.2
                self.get_logger().debug("Following wall on left")
            else:
                # Wall on right or no wall, turn slightly left
                self.cmd_vel_msg.angular.z = 0.2
                self.get_logger().debug("Following wall on right")
        
        self.cmd_pub.publish(self.cmd_vel_msg)
    
    def stop_robot(self):
        stop_msg = Twist()
        stop_msg.linear.x = 0.0
        stop_msg.angular.z = 0.0
        self.cmd_pub.publish(stop_msg)
        self.get_logger().debug("Robot stopped")

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def distance_to_goal(self):
        return math.sqrt((self.goal_x - self.current_x)**2 + (self.goal_y - self.current_y)**2)
    
    def goal_is_reached(self):
        return self.distance_to_goal() < 0.2
       
def main(args=None):
    rclpy.init(args=args)
    bug_node = Bug0()
    rclpy.spin(bug_node)
    bug_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()