import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from rclpy.parameter import Parameter
from rcl_interfaces.msg import ParameterDescriptor

class GoalPublisher(Node):
    def __init__(self):
        super().__init__('goal_publisher')
        
        # Declare parameters
        self.declare_parameter('x_goal', 4.0, 
            ParameterDescriptor(description='X coordinate of goal position'))
        self.declare_parameter('y_goal', 4.0, 
            ParameterDescriptor(description='Y coordinate of goal position'))
        
        # Create publisher
        self.goal_publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)
        
        # Create timer
        self.timer = self.create_timer(1.0, self.publish_goal)
        
        self.get_logger().info('Goal Publisher started')

    def publish_goal(self):
        # Get parameters
        x_goal = self.get_parameter('x_goal').value
        y_goal = self.get_parameter('y_goal').value
        
        # Create goal message
        goal_msg = PoseStamped()
        goal_msg.header.stamp = self.get_clock().now().to_msg()
        goal_msg.header.frame_id = 'map'
        goal_msg.pose.position.x = x_goal
        goal_msg.pose.position.y = y_goal
        goal_msg.pose.position.z = 0.0
        goal_msg.pose.orientation.w = 1.0
        
        # Publish goal
        self.goal_publisher.publish(goal_msg)
        self.get_logger().info(f'Published goal: x={x_goal}, y={y_goal}')

def main(args=None):
    rclpy.init(args=args)
    goal_publisher = GoalPublisher()
    rclpy.spin(goal_publisher)
    goal_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()