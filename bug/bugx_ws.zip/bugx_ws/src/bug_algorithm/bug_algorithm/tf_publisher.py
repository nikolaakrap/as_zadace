import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, TransformStamped
from nav_msgs.msg import Odometry
import tf2_ros
import tf_transformations

class TFPublisher(Node):
    def __init__(self):
        super().__init__('tf_publisher')
        
        # TF2 broadcaster
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        
        # Subscribe to robot position
        self.odom_sub = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10)
            
        # Subscribe to goal position
        self.goal_sub = self.create_subscription(
            PoseStamped,
            '/goal_pose',
            self.goal_callback,
            10)
            
        self.get_logger().info('TF publisher initialized - publishing robot and goal positions')

    def odom_callback(self, msg):
        # Create transform for robot position
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'map'
        t.child_frame_id = 'base_link'
        
        # Set translation
        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z
        
        # Set rotation
        t.transform.rotation = msg.pose.pose.orientation
        
        # Broadcast transform
        self.tf_broadcaster.sendTransform(t)
        
        # Also broadcast static transforms for range sensors
        self.publish_sensor_frames()

    def goal_callback(self, msg):
        # Create transform for goal position
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'map'
        t.child_frame_id = 'goal'
        
        # Set translation
        t.transform.translation.x = msg.pose.position.x
        t.transform.translation.y = msg.pose.position.y
        t.transform.translation.z = 0.0
        
        # Set rotation
        t.transform.rotation = msg.pose.orientation
        
        # Broadcast transform
        self.tf_broadcaster.sendTransform(t)
        
    def publish_sensor_frames(self):
        # Define sensor positions relative to base_link
        sensors = {
            'f_sensor_link': (0.2, 0.0, 0.0),   # Front
            'fl_sensor_link': (0.15, 0.15, 0.0), # Front-left
            'fr_sensor_link': (0.15, -0.15, 0.0), # Front-right
            'l_sensor_link': (0.0, 0.2, 0.0),    # Left
            'r_sensor_link': (0.0, -0.2, 0.0)    # Right
        }
        
        # Publish transforms for each sensor
        for name, (x, y, z) in sensors.items():
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = 'base_link'
            t.child_frame_id = name
            
            # Set translation
            t.transform.translation.x = x
            t.transform.translation.y = y
            t.transform.translation.z = z
            
            # Set rotation (identity)
            t.transform.rotation.w = 1.0
            
            # Broadcast transform
            self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    tf_publisher = TFPublisher()
    rclpy.spin(tf_publisher)
    tf_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()